class_name PlayerIdle
extends BaseState

@export var player : Player
var anim_player : AnimationPlayer

func enter():
	anim_player = player.get_node("AnimationPlayer")
	anim_player.play("idle")


func _input(event: InputEvent) -> void:
	handle_inputs(event)

func handle_inputs(input_event: InputEvent) -> void :
	var dir : float = Input.get_axis("left", "right")

	if (Input.is_action_just_pressed("attack")):
		Transitioned.emit(self, "PlayerAttack")
		
	elif Input.is_action_just_pressed("up") and player.is_on_floor():
		Transitioned.emit(self, "PlayerJump")
		
	elif (dir != 0):
		Transitioned.emit(self, "PlayerRun")

func update(delta: float) -> void:
	if not anim_player :
		anim_player = player.animation_player

func physics_update(delta: float) -> void:
	if not anim_player : return

	player.velocity.x = move_toward(player.velocity.x, 0, player.SPEED)

	if (not player.is_on_floor() and player.velocity.y >= 0):
		Transitioned.emit(self, "PlayerFall")
		
func exit() -> void:
	pass
