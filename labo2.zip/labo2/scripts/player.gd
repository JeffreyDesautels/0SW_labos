#class_name Player
#extends CharacterBody2D
#
#enum State { STATE_JUMPING, STATE_IDLE, STATE_RUNNING, STATE_FALLING, STATE_ATTACKING }
#var current_state: State = State.STATE_IDLE
#
#const SPEED = 150.0
#const JUMP_VELOCITY = -400.0
#var facing_right = true
#
#@onready var sprite_2d: Sprite2D = $Sprite2D
#@onready var animation_player: AnimationPlayer = $AnimationPlayer
#
#func _physics_process(delta: float) -> void:
	## Add the gravity.
	#if not is_on_floor():
		#velocity += get_gravity() * delta
#
	## Get the input direction and handle the movement/deceleration.
	## As good practice, you should replace UI actions with custom gameplay actions.
	#var direction := Input.get_axis("left", "right")
	#if direction:
		#velocity.x = direction * SPEED
	#else:
		#velocity.x = move_toward(velocity.x, 0, SPEED)
#
	#sprite_2d.scale.x = -1.0 if direction < 0 else 1.0
	#
	#match current_state:
		#
		#State.STATE_FALLING:
			#falling()
			#
		#State.STATE_IDLE:
			#idle(direction)
			#
		#State.STATE_JUMPING:
			#jumping()
			#
		#State.STATE_RUNNING:
			#running(direction)
			#
		##CORRIGER POUR FAIRE DURER LE TEMPS DE L'ANIMATION
		#State.STATE_ATTACKING:
			#attacking()
				#
		#_:
			#animation_player.play("idle")
#
#
	#move_and_slide()
#
#
#func falling() -> void:
	#if is_on_floor():
		#current_state = State.STATE_IDLE
		#animation_player.play("idle")
#
#
#func idle(direction) -> void:
	#if Input.is_action_just_pressed("attack"):
		#current_state = State.STATE_ATTACKING
		#animation_player.play("attack")
		#
	#elif Input.is_action_just_pressed("up") and is_on_floor():
		#current_state = State.STATE_JUMPING
		#velocity.y = JUMP_VELOCITY
		#animation_player.play("jump")
		#
	#elif direction != 0:
		#current_state = State.STATE_RUNNING
		#animation_player.play("run")
		#
	#elif not is_on_floor() and velocity.y > 0: 
		#current_state = State.STATE_FALLING
		#animation_player.play("fall")
#
#
#func jumping() -> void:
	#if velocity.y >= 0:
		#current_state = State.STATE_FALLING
		#animation_player.play("fall")
	#else:
		#animation_player.play("jump")
#
#
#func running(direction) -> void:
	#if direction > 0:
		#facing_right = true
	#elif direction < 0:
		#facing_right = false
	#else:
		#current_state = State.STATE_IDLE
		#animation_player.play("idle")
	#
	#if not is_on_floor() and velocity.y > 0:
		#current_state = State.STATE_FALLING
		#animation_player.play("fall")
	#elif Input.is_action_just_pressed("up"):
		#current_state = State.STATE_JUMPING
		#velocity.y = JUMP_VELOCITY
		#animation_player.play("jump")
	#
	#if Input.is_action_just_pressed("attack"):
		#current_state = State.STATE_ATTACKING
		##animation_player.play("attack")
#
#
#func attacking() -> void:
	#animation_player.play("attack")
	#current_state = State.STATE_IDLE





extends CharacterBody2D
class_name Player

const SPEED = 150.0
const JUMP_VELOCITY = -400.0

var facing_right = true

@onready var sprite_2d: Sprite2D = $Sprite2D
@onready var animation_player: AnimationPlayer = $AnimationPlayer

#func _ready() -> void:
	#animation_player.play("idle")


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	move_and_slide()
